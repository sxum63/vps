###
## __Free VPS Windows Free VPS Linux__
###
[![Typing SVG](https://readme-typing-svg.herokuapp.com?color=16D400&size=25&width=770&lines=Free+RDP+windows+on+vps+linux)](https://git.io/typing-svg)

###
wget -O su.sh https://bit.ly/akuhGet && chmod +x su.sh && ./su.sh
###
## [__Tutorials__ __Free Vps__](https://www.akuh.net/search/label/Vps)


###
###

