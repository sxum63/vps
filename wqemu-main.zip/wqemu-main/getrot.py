from google_drive_downloader import GoogleDriveDownloader as gdd

gdd.download_file_from_google_drive(file_id='1b9rn53R_gQoQzsoqL0Uq731bhLfGmq4K',
                                    dest_path='./akuh.zip',
                                    unzip=True)
